<?php

namespace Octfx\ScDataDumper\DocumentTypes;

final class VehicleDefinition extends EntityClassDefinition {}
