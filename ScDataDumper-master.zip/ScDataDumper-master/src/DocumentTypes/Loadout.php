<?php

declare(strict_types=1);

namespace Octfx\ScDataDumper\DocumentTypes;

final class Loadout extends RootDocument {}
