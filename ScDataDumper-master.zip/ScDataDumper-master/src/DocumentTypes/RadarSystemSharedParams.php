<?php

namespace Octfx\ScDataDumper\DocumentTypes;

final class RadarSystemSharedParams extends RootDocument {}
