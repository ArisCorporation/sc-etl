<?php

namespace Octfx\ScDataDumper\Definitions;

namespace Octfx\ScDataDumper\DocumentTypes;

final class MeleeCombatConfig extends RootDocument {}
