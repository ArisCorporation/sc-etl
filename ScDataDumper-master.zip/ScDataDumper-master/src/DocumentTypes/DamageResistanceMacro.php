<?php

namespace Octfx\ScDataDumper\DocumentTypes;

final class DamageResistanceMacro extends RootDocument {}
